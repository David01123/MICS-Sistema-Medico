package com.mics.login.controlador;

import com.mics.login.modelo.Paciente;
import com.mics.login.modelo.Procedimiento;
import com.mics.login.servicio.PacienteServicio;
import com.mics.login.servicio.ProcedimientoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;

@Controller
@RequestMapping("/procedimientos")
public class ProcedimientoControlador {

    @Autowired
    private ProcedimientoServicio servicio;

    @Autowired
    private PacienteServicio pacienteServicio;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("procedimientos", servicio.listarTodos());
        return "procedimientos/lista";
    }

    @GetMapping("/paciente/{cc}")
    public String listarPorPaciente(@PathVariable String cc, Model model) {
        Paciente paciente = pacienteServicio.buscarPorCc(cc)
            .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
        model.addAttribute("procedimientos", servicio.listarPorPaciente(cc));
        model.addAttribute("paciente", paciente);
        return "procedimientos/lista";
    }

    @GetMapping("/nuevo/{cc}")
    public String nuevo(@PathVariable String cc, Model model) {
        Paciente paciente = pacienteServicio.buscarPorCc(cc)
            .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
        Procedimiento proc = new Procedimiento();
        proc.setPaciente(paciente);
        proc.setFecha(LocalDateTime.now());
        model.addAttribute("procedimiento", proc);
        model.addAttribute("accion", "Registrar");
        return "procedimientos/formulario";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Procedimiento proc,
                          @RequestParam String ccPaciente,
                          RedirectAttributes flash) {
        try {
            Paciente paciente = pacienteServicio.buscarPorCc(ccPaciente)
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
            proc.setPaciente(paciente);
            if (proc.getFecha() == null) proc.setFecha(LocalDateTime.now());
            servicio.guardar(proc);
            flash.addFlashAttribute("exito", "Procedimiento registrado correctamente.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", "Error al guardar el procedimiento.");
        }
        return "redirect:/procedimientos/paciente/" + ccPaciente;
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes flash) {
        Procedimiento proc = servicio.buscarPorId(id)
            .orElseThrow(() -> new RuntimeException("Procedimiento no encontrado"));
        String cc = proc.getPaciente().getCcPaciente();
        try {
            servicio.eliminar(id);
            flash.addFlashAttribute("exito", "Procedimiento eliminado.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", "No se pudo eliminar el procedimiento.");
        }
        return "redirect:/procedimientos/paciente/" + cc;
    }
}
