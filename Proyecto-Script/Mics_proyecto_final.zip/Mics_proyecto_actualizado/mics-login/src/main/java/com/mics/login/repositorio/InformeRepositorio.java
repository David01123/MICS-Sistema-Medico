package com.mics.login.repositorio;

import com.mics.login.modelo.Informe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InformeRepositorio extends JpaRepository<Informe, Long> {

    List<Informe> findByPaciente_CcPaciente(String ccPaciente);
    List<Informe> findAllByOrderByFechaDesc();
}
