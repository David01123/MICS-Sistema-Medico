package com.mics.login.servicio;

import com.mics.login.modelo.Usuario;
import com.mics.login.repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioServicio implements UserDetailsService {

    @Autowired
    private UsuarioRepositorio repositorio;

    @Override
    public UserDetails loadUserByUsername(String nombreCuenta)
            throws UsernameNotFoundException {

        Usuario usuario = repositorio.findByNombreCuenta(nombreCuenta)
            .orElseThrow(() -> new UsernameNotFoundException(
                "Usuario no encontrado: " + nombreCuenta));

        // Convierte el rol de la BD al formato que Spring Security entiende
        return new org.springframework.security.core.userdetails.User(
            usuario.getNombreCuenta(),
            usuario.getContrasena(),
            List.of(new SimpleGrantedAuthority("ROLE_" + usuario.getRol()))
        );
    }
}