package com.mics.login.modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transferencia")
public class Transferencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id_Transferencia")
    private Integer idTransferencia;

    @Column(name = "Fecha", nullable = false)
    private LocalDateTime fecha;

    @Column(name = "Institucion_Origen", length = 100, nullable = false)
    private String institucionOrigen;

    @Column(name = "Institucion_Destino", length = 100, nullable = false)
    private String institucionDestino;

    @Column(name = "Estado", length = 20, nullable = false)
    private String estado; // PENDIENTE, COMPLETADA, RECHAZADA

    @Column(name = "Observaciones", length = 255)
    private String observaciones;

    @ManyToOne
    @JoinColumn(name = "CC_Paciente", nullable = false)
    private Paciente paciente;

    public Transferencia() {}

    // Getters y Setters
    public Integer      getIdTransferencia()              { return idTransferencia; }
    public void         setIdTransferencia(Integer v)      { this.idTransferencia = v; }

    public LocalDateTime getFecha()                        { return fecha; }
    public void          setFecha(LocalDateTime v)         { this.fecha = v; }

    public String        getInstitucionOrigen()            { return institucionOrigen; }
    public void          setInstitucionOrigen(String v)    { this.institucionOrigen = v; }

    public String        getInstitucionDestino()           { return institucionDestino; }
    public void          setInstitucionDestino(String v)   { this.institucionDestino = v; }

    public String        getEstado()                       { return estado; }
    public void          setEstado(String v)               { this.estado = v; }

    public String        getObservaciones()                { return observaciones; }
    public void          setObservaciones(String v)        { this.observaciones = v; }

    public Paciente      getPaciente()                     { return paciente; }
    public void          setPaciente(Paciente v)           { this.paciente = v; }
}