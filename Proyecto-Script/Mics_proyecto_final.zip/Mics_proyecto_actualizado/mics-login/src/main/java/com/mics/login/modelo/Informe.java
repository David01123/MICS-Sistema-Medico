package com.mics.login.modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "informe")
public class Informe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "titulo", length = 200, nullable = false)
    private String titulo;

    @Column(name = "nombre_archivo", length = 255, nullable = false)
    private String nombreArchivo;   // nombre del fichero en disco

    @Column(name = "ruta_archivo", length = 500, nullable = false)
    private String rutaArchivo;     // ruta absoluta en el servidor

    @Column(name = "subido_por", length = 50, nullable = false)
    private String subidoPor;       // nombreCuenta del usuario que subió

    @Column(name = "fecha", nullable = false)
    private LocalDateTime fecha;

    // Relación con paciente
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CC_Paciente", nullable = false)
    private Paciente paciente;

    public Informe() {}

    public Long          getId()             { return id; }
    public void          setId(Long v)       { this.id = v; }

    public String        getTitulo()         { return titulo; }
    public void          setTitulo(String v) { this.titulo = v; }

    public String        getNombreArchivo()          { return nombreArchivo; }
    public void          setNombreArchivo(String v)   { this.nombreArchivo = v; }

    public String        getRutaArchivo()            { return rutaArchivo; }
    public void          setRutaArchivo(String v)    { this.rutaArchivo = v; }

    public String        getSubidoPor()              { return subidoPor; }
    public void          setSubidoPor(String v)      { this.subidoPor = v; }

    public LocalDateTime getFecha()                  { return fecha; }
    public void          setFecha(LocalDateTime v)   { this.fecha = v; }

    public Paciente      getPaciente()               { return paciente; }
    public void          setPaciente(Paciente v)     { this.paciente = v; }
}
