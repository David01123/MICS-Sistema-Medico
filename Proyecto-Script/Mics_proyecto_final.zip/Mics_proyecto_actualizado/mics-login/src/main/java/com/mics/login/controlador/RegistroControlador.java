package com.mics.login.controlador;

import com.mics.login.modelo.Usuario;
import com.mics.login.repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RegistroControlador {

    @Autowired
    private UsuarioRepositorio repositorio;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "registro";
    }

    @PostMapping("/registro")
    public String procesarRegistro(
            @RequestParam String nombreCuenta,
            @RequestParam String contrasena,
            @RequestParam String confirmar,
            Model model) {

        if (nombreCuenta.trim().length() < 4) {
            model.addAttribute("error", "El nombre de usuario debe tener al menos 4 caracteres.");
            return "registro";
        }

        if (nombreCuenta.contains(" ")) {
            model.addAttribute("error", "El nombre de usuario no puede contener espacios.");
            return "registro";
        }

        if (contrasena.length() < 6) {
            model.addAttribute("error", "La contraseña debe tener al menos 6 caracteres.");
            return "registro";
        }

        if (!contrasena.equals(confirmar)) {
            model.addAttribute("error", "Las contraseñas no coinciden.");
            return "registro";
        }

        if (repositorio.findByNombreCuenta(nombreCuenta).isPresent()) {
            model.addAttribute("error", "Ese nombre de usuario ya está en uso.");
            return "registro";
        }

        // El rol siempre es MEDICO desde el registro público.
        // Los roles ADMIN se asignan solo desde el panel de administradores.
        Usuario nuevo = new Usuario();
        nuevo.setNombreCuenta(nombreCuenta);
        nuevo.setContrasena(passwordEncoder.encode(contrasena));
        nuevo.setRol("MEDICO");
        repositorio.save(nuevo);

        return "redirect:/login?registro=true";
    }
}
