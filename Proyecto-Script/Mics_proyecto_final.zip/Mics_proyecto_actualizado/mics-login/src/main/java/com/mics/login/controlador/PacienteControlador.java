package com.mics.login.controlador;

import com.mics.login.modelo.Administrador;
import com.mics.login.modelo.Paciente;
import com.mics.login.servicio.AdministradorServicio;
import com.mics.login.servicio.PacienteServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/pacientes")
public class PacienteControlador {

    @Autowired
    private PacienteServicio servicio;

    @Autowired
    private AdministradorServicio administradorServicio;

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int pagina,
                         @RequestParam(defaultValue = "") String buscar,
                         Model model) {
        if (!buscar.isBlank()) {
            model.addAttribute("pacientes", servicio.buscarPorNombre(buscar));
            model.addAttribute("totalPaginas", 1);
            model.addAttribute("paginaActual", 0);
        } else {
            Page<Paciente> pagePacientes = servicio.listarPaginado(PageRequest.of(pagina, 10));
            model.addAttribute("pacientes", pagePacientes.getContent());
            model.addAttribute("paginaActual", pagina);
            model.addAttribute("totalPaginas", pagePacientes.getTotalPages());
        }
        model.addAttribute("buscar", buscar);
        return "pacientes/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("paciente", new Paciente());
        model.addAttribute("accion", "Registrar");
        model.addAttribute("administradores", administradorServicio.listarTodos());
        return "pacientes/formulario";
    }

    @PostMapping("/guardar")
    public String guardar(
            @RequestParam String ccPaciente,
            @RequestParam String nombrePaciente,
            @RequestParam String apellidoPaciente,
            @RequestParam(required = false) String telefonoPaciente,
            @RequestParam(required = false) String generoPaciente,
            @RequestParam(required = false) String departamentoPaciente,
            @RequestParam(required = false) Integer idAdministrador,
            RedirectAttributes flash) {
        try {
            Paciente paciente = servicio.buscarPorCc(ccPaciente).orElse(new Paciente());
            paciente.setCcPaciente(ccPaciente);
            paciente.setNombrePaciente(nombrePaciente);
            paciente.setApellidoPaciente(apellidoPaciente);
            paciente.setTelefonoPaciente(telefonoPaciente);
            paciente.setGeneroPaciente(generoPaciente);
            paciente.setDepartamentoPaciente(departamentoPaciente);
            if (idAdministrador != null) {
                administradorServicio.buscarPorId(idAdministrador)
                    .ifPresent(paciente::setAdministrador);
            } else {
                paciente.setAdministrador(null);
            }
            servicio.guardar(paciente);
            flash.addFlashAttribute("exito", "Paciente guardado correctamente.");
            return "redirect:/pacientes";
        } catch (Exception e) {
            flash.addFlashAttribute("error", "Error al guardar: " + e.getMessage());
            return "redirect:/pacientes/nuevo";
        }
    }

    @GetMapping("/editar/{cc}")
    public String editar(@PathVariable String cc, Model model) {
        Paciente paciente = servicio.buscarPorCc(cc)
            .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
        model.addAttribute("paciente", paciente);
        model.addAttribute("accion", "Actualizar");
        model.addAttribute("administradores", administradorServicio.listarTodos());
        return "pacientes/formulario";
    }

    @GetMapping("/eliminar/{cc}")
    public String eliminar(@PathVariable String cc, RedirectAttributes flash) {
        try {
            servicio.eliminar(cc);
            flash.addFlashAttribute("exito", "Paciente eliminado.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", "No se pudo eliminar: el paciente tiene procedimientos o transferencias asociadas.");
        }
        return "redirect:/pacientes";
    }
}
