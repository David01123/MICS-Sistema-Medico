package com.mics.login.controlador;

import com.mics.login.modelo.Paciente;
import com.mics.login.modelo.Transferencia;
import com.mics.login.servicio.PacienteServicio;
import com.mics.login.servicio.TransferenciaServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;

@Controller
@RequestMapping("/transferencias")
public class TransferenciaControlador {

    @Autowired
    private TransferenciaServicio servicio;

    @Autowired
    private PacienteServicio pacienteServicio;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("transferencias", servicio.listarTodas());
        model.addAttribute("pacientes", pacienteServicio.listarTodos());
        return "transferencias/lista";
    }

    @GetMapping("/nueva")
    public String nueva(Model model) {
        Transferencia t = new Transferencia();
        t.setFecha(LocalDateTime.now());
        t.setEstado("PENDIENTE");
        model.addAttribute("transferencia", t);
        model.addAttribute("pacientes", pacienteServicio.listarTodos());
        return "transferencias/formulario";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Transferencia transferencia,
                          @RequestParam String ccPaciente,
                          RedirectAttributes flash) {
        try {
            Paciente paciente = pacienteServicio.buscarPorCc(ccPaciente)
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
            transferencia.setPaciente(paciente);
            if (transferencia.getFecha() == null)
                transferencia.setFecha(LocalDateTime.now());
            servicio.guardar(transferencia);
            flash.addFlashAttribute("exito", "Transferencia guardada correctamente.");
            return "redirect:/transferencias";
        } catch (Exception e) {
            flash.addFlashAttribute("error", "Error al guardar la transferencia: " + e.getMessage());
            return "redirect:/transferencias/nueva";
        }
    }

    private static final java.util.Set<String> ESTADOS_VALIDOS =
        java.util.Set.of("PENDIENTE", "COMPLETADA", "RECHAZADA");

    @GetMapping("/estado/{id}/{estado}")
    public String actualizarEstado(@PathVariable Integer id,
                                   @PathVariable String estado,
                                   RedirectAttributes flash) {
        if (!ESTADOS_VALIDOS.contains(estado.toUpperCase())) {
            flash.addFlashAttribute("error", "Estado inválido: " + estado);
            return "redirect:/transferencias";
        }
        servicio.buscarPorId(id).ifPresentOrElse(t -> {
            t.setEstado(estado.toUpperCase());
            servicio.guardar(t);
            flash.addFlashAttribute("exito", "Estado actualizado a: " + estado);
        }, () -> flash.addFlashAttribute("error", "Transferencia no encontrada."));
        return "redirect:/transferencias";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes flash) {
        try {
            servicio.eliminar(id);
            flash.addFlashAttribute("exito", "Transferencia eliminada.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", "No se pudo eliminar la transferencia.");
        }
        return "redirect:/transferencias";
    }
}
