package com.mics.login;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class GenerarHash {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String password = "admin123";
        System.out.println(encoder.encode(password));
        System.out.println("Verificacion: " + encoder.matches(password, encoder.encode(password)));
    }
}