package com.mics.login.repositorio;

import com.mics.login.modelo.Transferencia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TransferenciaRepositorio extends JpaRepository<Transferencia, Integer> {

    List<Transferencia> findByPaciente_CcPaciente(String ccPaciente);
    List<Transferencia> findByEstado(String estado);
}