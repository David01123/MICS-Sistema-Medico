package com.mics.login.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "cuenta")
public class Usuario {

    @Id
    @Column(name = "Nombre_Cuenta", length = 50)
    private String nombreCuenta;

    @Column(name = "Contrasena", length = 255, nullable = false)
    private String contrasena;

    @Column(name = "Rol", length = 20, nullable = false)
    private String rol;

    // Constructor vacío obligatorio para JPA
    public Usuario() {}

    public Usuario(String nombreCuenta, String contrasena, String rol) {
        this.nombreCuenta = nombreCuenta;
        this.contrasena   = contrasena;
        this.rol           = rol;
    }

    // ── Getters y Setters ──────────────────────────────

    public String getNombreCuenta() {
        return nombreCuenta;
    }
    public void setNombreCuenta(String nombreCuenta) {
        this.nombreCuenta = nombreCuenta;
    }

    public String getContrasena() {
        return contrasena;
    }
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getRol() {
        return rol;
    }
    public void setRol(String rol) {
        this.rol = rol;
    }
}