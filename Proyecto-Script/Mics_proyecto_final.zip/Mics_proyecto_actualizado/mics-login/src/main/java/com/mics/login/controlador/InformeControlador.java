package com.mics.login.controlador;

import com.mics.login.modelo.Informe;
import com.mics.login.modelo.InformeDTO;
import com.mics.login.modelo.Paciente;
import com.mics.login.repositorio.InformeRepositorio;
import com.mics.login.servicio.PacienteServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/informes")
public class InformeControlador {

    // Carpeta donde se guardan los PDFs. Se puede configurar en application.properties
    // con: informes.upload-dir=./uploads/informes
    @Value("${informes.upload-dir:./uploads/informes}")
    private String uploadDir;

    @Autowired
    private InformeRepositorio informeRepo;

    @Autowired
    private PacienteServicio pacienteServicio;

    // ── Listar todos los informes ─────────────────────────────────────────────
    @GetMapping
    public String listar(Model model) {
        List<InformeDTO> dtos = informeRepo.findAllByOrderByFechaDesc()
            .stream()
            .map(this::toDTO)
            .collect(Collectors.toList());

        model.addAttribute("informes", dtos);
        model.addAttribute("pacientes", pacienteServicio.listarTodos());
        return "informes/lista";
    }

    // ── Subir nuevo informe ───────────────────────────────────────────────────
    @PostMapping("/subir")
    public String subir(@RequestParam String ccPaciente,
                        @RequestParam String titulo,
                        @RequestParam MultipartFile archivo,
                        Authentication auth,
                        RedirectAttributes flash) {

        // Validar que sea PDF
        if (archivo.isEmpty() || !isPdf(archivo)) {
            flash.addFlashAttribute("error", "Solo se permiten archivos PDF.");
            return "redirect:/informes";
        }

        // Validar tamaño (máx 10 MB)
        if (archivo.getSize() > 10 * 1024 * 1024) {
            flash.addFlashAttribute("error", "El archivo no debe superar los 10 MB.");
            return "redirect:/informes";
        }

        try {
            Paciente paciente = pacienteServicio.buscarPorCc(ccPaciente)
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));

            // Crear carpeta si no existe
            Path dir = Paths.get(uploadDir);
            Files.createDirectories(dir);

            // Nombre único para evitar colisiones
            String nombreArchivo = UUID.randomUUID() + "_" + archivo.getOriginalFilename();
            Path destino = dir.resolve(nombreArchivo);
            Files.copy(archivo.getInputStream(), destino, StandardCopyOption.REPLACE_EXISTING);

            Informe informe = new Informe();
            informe.setTitulo(titulo.trim());
            informe.setNombreArchivo(nombreArchivo);
            informe.setRutaArchivo(destino.toAbsolutePath().toString());
            informe.setSubidoPor(auth.getName());
            informe.setFecha(LocalDateTime.now());
            informe.setPaciente(paciente);
            informeRepo.save(informe);

            flash.addFlashAttribute("exito", "Informe subido correctamente.");
        } catch (IOException e) {
            flash.addFlashAttribute("error", "Error al guardar el archivo: " + e.getMessage());
        } catch (Exception e) {
            flash.addFlashAttribute("error", "Error: " + e.getMessage());
        }
        return "redirect:/informes";
    }

    // ── Ver / descargar PDF ───────────────────────────────────────────────────
    @GetMapping("/ver/{id}")
    public ResponseEntity<Resource> verPdf(@PathVariable Long id) {
        Informe informe = informeRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Informe no encontrado"));
        try {
            Path ruta = Paths.get(informe.getRutaArchivo());
            Resource recurso = new UrlResource(ruta.toUri());
            if (!recurso.exists()) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + informe.getNombreArchivo() + "\"")
                .body(recurso);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // ── Eliminar informe (solo ADMIN, controlado en SecurityConfig) ───────────
    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes flash) {
        informeRepo.findById(id).ifPresent(inf -> {
            // Borrar archivo físico
            try { Files.deleteIfExists(Paths.get(inf.getRutaArchivo())); }
            catch (IOException ignored) {}
            informeRepo.delete(inf);
        });
        flash.addFlashAttribute("exito", "Informe eliminado.");
        return "redirect:/informes";
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private InformeDTO toDTO(Informe inf) {
        InformeDTO dto = new InformeDTO();
        dto.setId(inf.getId());
        dto.setTitulo(inf.getTitulo());
        dto.setNombrePaciente(
            inf.getPaciente().getNombrePaciente() + " " + inf.getPaciente().getApellidoPaciente());
        dto.setSubidoPor(inf.getSubidoPor());
        dto.setFechaFormateada(
            inf.getFecha().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
        dto.setRutaArchivo(inf.getRutaArchivo());
        return dto;
    }

    private boolean isPdf(MultipartFile file) {
        String ct = file.getContentType();
        String name = file.getOriginalFilename();
        return "application/pdf".equalsIgnoreCase(ct)
            || (name != null && name.toLowerCase().endsWith(".pdf"));
    }
}
