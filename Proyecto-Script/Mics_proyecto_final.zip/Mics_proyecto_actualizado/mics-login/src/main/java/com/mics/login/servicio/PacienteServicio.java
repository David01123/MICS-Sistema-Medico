package com.mics.login.servicio;

import com.mics.login.modelo.Paciente;
import com.mics.login.repositorio.PacienteRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PacienteServicio {

    @Autowired
    private PacienteRepositorio repositorio;

    public List<Paciente> listarTodos() {
        return repositorio.findAll();
    }

    public Page<Paciente> listarPaginado(Pageable pageable) {
        return repositorio.findAll(pageable);
    }

    public Optional<Paciente> buscarPorCc(String cc) {
        return repositorio.findById(cc);
    }

    public List<Paciente> buscarPorNombre(String nombre) {
        return repositorio.findByNombrePacienteContainingIgnoreCase(nombre);
    }

    public Paciente guardar(Paciente paciente) {
        return repositorio.save(paciente);
    }

    public void eliminar(String cc) {
        repositorio.deleteById(cc);
    }
}
