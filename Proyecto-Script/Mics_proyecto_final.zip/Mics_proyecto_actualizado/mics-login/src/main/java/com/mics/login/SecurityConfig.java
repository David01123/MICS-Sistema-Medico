package com.mics.login;

import com.mics.login.servicio.UsuarioServicio;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final UsuarioServicio usuarioServicio;

    public SecurityConfig(UsuarioServicio usuarioServicio) {
        this.usuarioServicio = usuarioServicio;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(usuarioServicio);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authenticationProvider(authProvider())
            .authorizeHttpRequests(auth -> auth

                // Recursos públicos
                .requestMatchers("/css/**", "/js/**", "/images/**").permitAll()
                .requestMatchers("/registro").permitAll()

                // ── Módulo ADMINISTRADORES: solo ADMIN ──────────────────
                .requestMatchers("/administradores/**").hasRole("ADMIN")

                // ── Módulo PACIENTES ────────────────────────────────────
                // Eliminar paciente: solo ADMIN
                .requestMatchers(HttpMethod.GET, "/pacientes/eliminar/**").hasRole("ADMIN")
                // Crear / editar paciente: solo ADMIN
                .requestMatchers(HttpMethod.GET,  "/pacientes/nuevo").hasRole("ADMIN")
                .requestMatchers(HttpMethod.GET,  "/pacientes/editar/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/pacientes/guardar").hasRole("ADMIN")
                // Ver lista de pacientes: ADMIN y MEDICO
                .requestMatchers("/pacientes/**").hasAnyRole("ADMIN", "MEDICO")

                // ── Módulo TRANSFERENCIAS ───────────────────────────────
                // Crear / eliminar transferencia: solo ADMIN
                .requestMatchers(HttpMethod.GET,  "/transferencias/nueva").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/transferencias/guardar").hasRole("ADMIN")
                .requestMatchers(HttpMethod.GET,  "/transferencias/eliminar/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.GET,  "/transferencias/estado/**").hasRole("ADMIN")
                // Ver lista: ADMIN y MEDICO
                .requestMatchers("/transferencias/**").hasAnyRole("ADMIN", "MEDICO")

                // ── Módulo INFORMES PDF ─────────────────────────────────
                // Eliminar informe: solo ADMIN
                .requestMatchers(HttpMethod.GET,  "/informes/eliminar/**").hasRole("ADMIN")
                // Subir y ver: ADMIN y MEDICO
                .requestMatchers(HttpMethod.POST, "/informes/subir").hasAnyRole("ADMIN", "MEDICO")
                .requestMatchers("/informes/**").hasAnyRole("ADMIN", "MEDICO")

                // ── Módulo PROCEDIMIENTOS ───────────────────────────────
                // Eliminar procedimiento: solo ADMIN
                .requestMatchers(HttpMethod.GET,  "/procedimientos/eliminar/**").hasRole("ADMIN")
                // Crear procedimiento: ADMIN y MEDICO
                .requestMatchers(HttpMethod.GET,  "/procedimientos/nuevo/**").hasAnyRole("ADMIN", "MEDICO")
                .requestMatchers(HttpMethod.POST, "/procedimientos/guardar").hasAnyRole("ADMIN", "MEDICO")
                // Ver: ADMIN y MEDICO
                .requestMatchers("/procedimientos/**").hasAnyRole("ADMIN", "MEDICO")

                // Todo lo demás requiere autenticación
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/home", true)
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutSuccessUrl("/login?logout=true")
                .permitAll()
            );
        return http.build();
    }
}
