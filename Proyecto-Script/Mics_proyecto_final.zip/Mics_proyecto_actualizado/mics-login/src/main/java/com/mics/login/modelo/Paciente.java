package com.mics.login.modelo;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "paciente")
public class Paciente {

    @Id
    @Column(name = "CC_Paciente", length = 20)
    private String ccPaciente;

    @Column(name = "Nombre_Paciente", length = 80, nullable = false)
    private String nombrePaciente;

    @Column(name = "Apellido_Paciente", length = 80, nullable = false)
    private String apellidoPaciente;

    @Column(name = "Telefono_Paciente", length = 20)
    private String telefonoPaciente;

    @Column(name = "Genero_Paciente", length = 1)
    private String generoPaciente;

    @Column(name = "Departamento_Paciente", length = 80)
    private String departamentoPaciente;

    // Relación real @ManyToOne con Administrador
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CC_Administrador", referencedColumnName = "Id_Administrador")
    private Administrador administrador;

    @OneToMany(mappedBy = "paciente", cascade = CascadeType.ALL)
    private List<Procedimiento> procedimientos;

    @OneToMany(mappedBy = "paciente", cascade = CascadeType.ALL)
    private List<Transferencia> transferencias;

    public Paciente() {}

    public String  getCcPaciente()                           { return ccPaciente; }
    public void    setCcPaciente(String v)                    { this.ccPaciente = v; }

    public String  getNombrePaciente()                       { return nombrePaciente; }
    public void    setNombrePaciente(String v)                { this.nombrePaciente = v; }

    public String  getApellidoPaciente()                     { return apellidoPaciente; }
    public void    setApellidoPaciente(String v)              { this.apellidoPaciente = v; }

    public String  getTelefonoPaciente()                     { return telefonoPaciente; }
    public void    setTelefonoPaciente(String v)              { this.telefonoPaciente = v; }

    public String  getGeneroPaciente()                       { return generoPaciente; }
    public void    setGeneroPaciente(String v)                { this.generoPaciente = v; }

    public String  getDepartamentoPaciente()                 { return departamentoPaciente; }
    public void    setDepartamentoPaciente(String v)          { this.departamentoPaciente = v; }

    public Administrador getAdministrador()                  { return administrador; }
    public void          setAdministrador(Administrador v)    { this.administrador = v; }

    public List<Procedimiento> getProcedimientos()           { return procedimientos; }
    public void    setProcedimientos(List<Procedimiento> v)   { this.procedimientos = v; }

    public List<Transferencia> getTransferencias()           { return transferencias; }
    public void    setTransferencias(List<Transferencia> v)   { this.transferencias = v; }
}
