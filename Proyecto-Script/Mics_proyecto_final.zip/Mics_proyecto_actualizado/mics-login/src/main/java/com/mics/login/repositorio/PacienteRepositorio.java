package com.mics.login.repositorio;

import com.mics.login.modelo.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PacienteRepositorio extends JpaRepository<Paciente, String> {

    // Buscar pacientes por nombre (para el buscador)
    List<Paciente> findByNombrePacienteContainingIgnoreCase(String nombre);
}