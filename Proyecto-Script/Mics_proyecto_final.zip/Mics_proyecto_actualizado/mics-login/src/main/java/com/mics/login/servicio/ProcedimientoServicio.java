package com.mics.login.servicio;

import com.mics.login.modelo.Procedimiento;
import com.mics.login.repositorio.ProcedimientoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProcedimientoServicio {

    @Autowired
    private ProcedimientoRepositorio repositorio;

    public List<Procedimiento> listarTodos() {
        return repositorio.findAll();
    }

    public List<Procedimiento> listarPorPaciente(String ccPaciente) {
        return repositorio.findByPaciente_CcPaciente(ccPaciente);
    }

    public Optional<Procedimiento> buscarPorId(Integer id) {
        return repositorio.findById(id);
    }

    public Procedimiento guardar(Procedimiento procedimiento) {
        return repositorio.save(procedimiento);
    }

    public void eliminar(Integer id) {
        repositorio.deleteById(id);
    }
}