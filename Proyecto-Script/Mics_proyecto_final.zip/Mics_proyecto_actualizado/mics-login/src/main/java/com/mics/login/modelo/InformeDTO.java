package com.mics.login.modelo;

public class InformeDTO {

    private Long id;
    private String titulo;
    private String nombrePaciente;
    private String subidoPor;
    private String fechaFormateada;
    private String rutaArchivo;

    public InformeDTO() {}

    public Long   getId()              { return id; }
    public void   setId(Long v)        { this.id = v; }

    public String getTitulo()          { return titulo; }
    public void   setTitulo(String v)  { this.titulo = v; }

    public String getNombrePaciente()           { return nombrePaciente; }
    public void   setNombrePaciente(String v)   { this.nombrePaciente = v; }

    public String getSubidoPor()               { return subidoPor; }
    public void   setSubidoPor(String v)        { this.subidoPor = v; }

    public String getFechaFormateada()          { return fechaFormateada; }
    public void   setFechaFormateada(String v)  { this.fechaFormateada = v; }

    public String getRutaArchivo()             { return rutaArchivo; }
    public void   setRutaArchivo(String v)     { this.rutaArchivo = v; }
}
