package com.mics.login.modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "procedimientop")
public class Procedimiento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id_Historial")
    private Integer idHistorial;

    @Column(name = "Fecha")
    private LocalDateTime fecha;

    @Column(name = "Drec_Proc", length = 255)
    private String descripcion;

    @ManyToOne
    @JoinColumn(name = "CC_Paciente", nullable = false)
    private Paciente paciente;

    // Constructor vacío obligatorio para JPA
    public Procedimiento() {}

    // Getters y Setters
    public Integer       getIdHistorial()             { return idHistorial; }
    public void          setIdHistorial(Integer v)     { this.idHistorial = v; }

    public LocalDateTime getFecha()                   { return fecha; }
    public void          setFecha(LocalDateTime v)     { this.fecha = v; }

    public String        getDescripcion()             { return descripcion; }
    public void          setDescripcion(String v)      { this.descripcion = v; }

    public Paciente      getPaciente()                { return paciente; }
    public void          setPaciente(Paciente v)       { this.paciente = v; 

    }
}