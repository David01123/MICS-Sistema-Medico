package com.mics.login.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "administrador")
public class Administrador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id_Administrador")
    private Integer idAdministrador;

    @Column(name = "Nombre_Admin", length = 80, nullable = false)
    private String nombreAdmin;

    @Column(name = "Apellido_Admin", length = 80, nullable = false)
    private String apellidoAdmin;

    @Column(name = "CC_Admin", length = 20)
    private String ccAdmin;

    @Column(name = "Genero_Admin", length = 1)
    private String generoAdmin;

    @Column(name = "TelefonoAdmin", length = 20)
    private String telefonoAdmin;

    @Column(name = "Nombre_Cuenta", length = 50)
    private String nombreCuenta;

    // Constructor vacío obligatorio para JPA
    public Administrador() {}

    // Getters y Setters
    public Integer getIdAdministrador()              { return idAdministrador; }
    public void    setIdAdministrador(Integer v)      { this.idAdministrador = v; }

    public String  getNombreAdmin()                  { return nombreAdmin; }
    public void    setNombreAdmin(String v)           { this.nombreAdmin = v; }

    public String  getApellidoAdmin()                { return apellidoAdmin; }
    public void    setApellidoAdmin(String v)         { this.apellidoAdmin = v; }

    public String  getCcAdmin()                      { return ccAdmin; }
    public void    setCcAdmin(String v)               { this.ccAdmin = v; }

    public String  getGeneroAdmin()                  { return generoAdmin; }
    public void    setGeneroAdmin(String v)           { this.generoAdmin = v; }

    public String  getTelefonoAdmin()                { return telefonoAdmin; }
    public void    setTelefonoAdmin(String v)         { this.telefonoAdmin = v; }

    public String  getNombreCuenta()                 { return nombreCuenta; }
    public void    setNombreCuenta(String v)          { this.nombreCuenta = v; }
}