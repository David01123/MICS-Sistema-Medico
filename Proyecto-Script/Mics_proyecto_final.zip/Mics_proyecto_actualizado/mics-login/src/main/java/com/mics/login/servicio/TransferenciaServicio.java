package com.mics.login.servicio;

import com.mics.login.modelo.Transferencia;
import com.mics.login.repositorio.TransferenciaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TransferenciaServicio {

    @Autowired
    private TransferenciaRepositorio repositorio;

    public List<Transferencia> listarTodas() {
        return repositorio.findAll();
    }

    public List<Transferencia> listarPorPaciente(String ccPaciente) {
        return repositorio.findByPaciente_CcPaciente(ccPaciente);
    }

    public List<Transferencia> listarPorEstado(String estado) {
        return repositorio.findByEstado(estado);
    }

    public Optional<Transferencia> buscarPorId(Integer id) {
        return repositorio.findById(id);
    }

    public Transferencia guardar(Transferencia t) {
        return repositorio.save(t);
    }

    public void eliminar(Integer id) {
        repositorio.deleteById(id);
    }
}