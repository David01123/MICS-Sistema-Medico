package com.mics.login.controlador;

import com.mics.login.modelo.Administrador;
import com.mics.login.modelo.Usuario;
import com.mics.login.repositorio.UsuarioRepositorio;
import com.mics.login.servicio.AdministradorServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/administradores")
public class AdministradorControlador {

    @Autowired
    private AdministradorServicio servicio;

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("administradores", servicio.listarTodos());
        return "administrador/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("administrador", new Administrador());
        model.addAttribute("accion", "Registrar");
        return "administrador/formulario";
    }

    @PostMapping("/guardar")
    public String guardar(
            @RequestParam(required = false) Integer idAdministrador,
            @RequestParam String nombreAdmin,
            @RequestParam String apellidoAdmin,
            @RequestParam(required = false) String ccAdmin,
            @RequestParam(required = false) String generoAdmin,
            @RequestParam(required = false) String telefonoAdmin,
            @RequestParam String nombreCuenta,
            @RequestParam(required = false) String contrasena,
            @RequestParam String rol,
            RedirectAttributes flash) {
        try {
            // 1. Validar contraseña antes de tocar la BD
            boolean esNuevo = idAdministrador == null;
            if (esNuevo && (contrasena == null || contrasena.isEmpty())) {
                flash.addFlashAttribute("error", "La contraseña es obligatoria al crear un administrador.");
                return "redirect:/administradores/nuevo";
            }
            if (contrasena != null && !contrasena.isEmpty() && contrasena.length() < 6) {
                flash.addFlashAttribute("error", "La contraseña debe tener al menos 6 caracteres.");
                return "redirect:/administradores/" + (esNuevo ? "nuevo" : "editar/" + idAdministrador);
            }

            // 2. Guardar primero la cuenta (tabla `cuenta`) para satisfacer la FK
            Usuario usuario = usuarioRepositorio.findByNombreCuenta(nombreCuenta)
                .orElse(new Usuario());
            usuario.setNombreCuenta(nombreCuenta);
            usuario.setRol(rol);
            if (contrasena != null && !contrasena.isEmpty()) {
                usuario.setContrasena(passwordEncoder.encode(contrasena));
            }
            usuarioRepositorio.save(usuario);

            // 3. Ahora sí guardar el administrador (la FK ya existe en `cuenta`)
            Administrador admin = idAdministrador != null ?
                servicio.buscarPorId(idAdministrador).orElse(new Administrador()) :
                new Administrador();

            admin.setNombreAdmin(nombreAdmin);
            admin.setApellidoAdmin(apellidoAdmin);
            admin.setCcAdmin(ccAdmin);
            admin.setGeneroAdmin(generoAdmin);
            admin.setTelefonoAdmin(telefonoAdmin);
            admin.setNombreCuenta(nombreCuenta);
            servicio.guardar(admin);

            flash.addFlashAttribute("exito", "Administrador guardado correctamente.");
            return "redirect:/administradores";
        } catch (Exception e) {
            flash.addFlashAttribute("error", "Error al guardar: " + e.getMessage());
            String destino = (idAdministrador == null) ? "/administradores/nuevo"
                                                       : "/administradores/editar/" + idAdministrador;
            return "redirect:" + destino;
        }
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        Administrador admin = servicio.buscarPorId(id)
            .orElseThrow(() -> new RuntimeException("Administrador no encontrado"));
        model.addAttribute("administrador", admin);
        model.addAttribute("accion", "Actualizar");
        return "administrador/formulario";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id, RedirectAttributes flash) {
        try {
            servicio.eliminar(id);
            flash.addFlashAttribute("exito", "Administrador eliminado.");
        } catch (Exception e) {
            flash.addFlashAttribute("error", "No se pudo eliminar: tiene pacientes asociados.");
        }
        return "redirect:/administradores";
    }
}
