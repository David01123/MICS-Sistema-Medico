package com.mics.login.repositorio;

import com.mics.login.modelo.Procedimiento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProcedimientoRepositorio extends JpaRepository<Procedimiento, Integer> {

    // Traer todos los procedimientos de un paciente específico
    List<Procedimiento> findByPaciente_CcPaciente(String ccPaciente);
}