package com.mics.login.servicio;

import com.mics.login.modelo.Administrador;
import com.mics.login.repositorio.AdministradorRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdministradorServicio {

    @Autowired
    private AdministradorRepositorio repositorio;

    public List<Administrador> listarTodos() {
        return repositorio.findAll();
    }

    public Optional<Administrador> buscarPorId(Integer id) {
        return repositorio.findById(id);
    }

    public Administrador guardar(Administrador admin) {
        return repositorio.save(admin);
    }

    public void eliminar(Integer id) {
        repositorio.deleteById(id);
    }
}