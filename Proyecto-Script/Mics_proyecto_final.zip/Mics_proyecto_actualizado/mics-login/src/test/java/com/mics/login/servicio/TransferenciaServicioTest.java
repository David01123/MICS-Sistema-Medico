package com.mics.login.servicio;

import com.mics.login.modelo.Paciente;
import com.mics.login.modelo.Transferencia;
import com.mics.login.repositorio.TransferenciaRepositorio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransferenciaServicioTest {

    @Mock
    private TransferenciaRepositorio repositorio;

    @InjectMocks
    private TransferenciaServicio servicio;

    @Test
    void listarPorEstado_filtraCorrecto() {
        Transferencia t = new Transferencia();
        t.setEstado("PENDIENTE");
        t.setFecha(LocalDateTime.now());
        t.setInstitucionOrigen("Hospital A");
        t.setInstitucionDestino("Clinica B");
        Paciente p = new Paciente();
        p.setCcPaciente("111");
        t.setPaciente(p);

        when(repositorio.findByEstado("PENDIENTE")).thenReturn(List.of(t));

        List<Transferencia> resultado = servicio.listarPorEstado("PENDIENTE");
        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getEstado()).isEqualTo("PENDIENTE");
    }

    @Test
    void guardar_invocaRepositorio() {
        Transferencia t = new Transferencia();
        when(repositorio.save(t)).thenReturn(t);
        servicio.guardar(t);
        verify(repositorio, times(1)).save(t);
    }
}
