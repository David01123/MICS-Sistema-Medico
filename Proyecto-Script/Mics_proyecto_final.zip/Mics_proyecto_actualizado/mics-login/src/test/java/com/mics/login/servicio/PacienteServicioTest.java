package com.mics.login.servicio;

import com.mics.login.modelo.Paciente;
import com.mics.login.repositorio.PacienteRepositorio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PacienteServicioTest {

    @Mock
    private PacienteRepositorio repositorio;

    @InjectMocks
    private PacienteServicio servicio;

    private Paciente paciente;

    @BeforeEach
    void setUp() {
        paciente = new Paciente();
        paciente.setCcPaciente("12345678");
        paciente.setNombrePaciente("Juan");
        paciente.setApellidoPaciente("Pérez");
    }

    @Test
    void listarTodos_retornaLista() {
        when(repositorio.findAll()).thenReturn(List.of(paciente));
        List<Paciente> resultado = servicio.listarTodos();
        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getNombrePaciente()).isEqualTo("Juan");
    }

    @Test
    void buscarPorCc_existente_retornaPaciente() {
        when(repositorio.findById("12345678")).thenReturn(Optional.of(paciente));
        Optional<Paciente> resultado = servicio.buscarPorCc("12345678");
        assertThat(resultado).isPresent();
        assertThat(resultado.get().getCcPaciente()).isEqualTo("12345678");
    }

    @Test
    void buscarPorCc_inexistente_retornaVacio() {
        when(repositorio.findById("99999999")).thenReturn(Optional.empty());
        Optional<Paciente> resultado = servicio.buscarPorCc("99999999");
        assertThat(resultado).isEmpty();
    }

    @Test
    void guardar_invocaRepositorio() {
        when(repositorio.save(paciente)).thenReturn(paciente);
        Paciente guardado = servicio.guardar(paciente);
        assertThat(guardado.getNombrePaciente()).isEqualTo("Juan");
        verify(repositorio, times(1)).save(paciente);
    }

    @Test
    void eliminar_invocaDeleteById() {
        servicio.eliminar("12345678");
        verify(repositorio, times(1)).deleteById("12345678");
    }
}
