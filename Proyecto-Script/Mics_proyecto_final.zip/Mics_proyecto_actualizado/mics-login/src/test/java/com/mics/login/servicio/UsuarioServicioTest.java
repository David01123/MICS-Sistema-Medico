package com.mics.login.servicio;

import com.mics.login.modelo.Usuario;
import com.mics.login.repositorio.UsuarioRepositorio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UsuarioServicioTest {

    @Mock
    private UsuarioRepositorio repositorio;

    @InjectMocks
    private UsuarioServicio servicio;

    @Test
    void loadUserByUsername_usuarioExiste_retornaUserDetails() {
        Usuario usuario = new Usuario("admin", "$2a$10$hashedpassword", "ADMIN");
        when(repositorio.findByNombreCuenta("admin")).thenReturn(Optional.of(usuario));

        UserDetails details = servicio.loadUserByUsername("admin");

        assertThat(details.getUsername()).isEqualTo("admin");
        assertThat(details.getAuthorities())
            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
    }

    @Test
    void loadUserByUsername_usuarioNoExiste_lanzaExcepcion() {
        when(repositorio.findByNombreCuenta("noexiste")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> servicio.loadUserByUsername("noexiste"))
            .isInstanceOf(UsernameNotFoundException.class)
            .hasMessageContaining("noexiste");
    }
}
