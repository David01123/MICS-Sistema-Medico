package com.mics.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicsLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
