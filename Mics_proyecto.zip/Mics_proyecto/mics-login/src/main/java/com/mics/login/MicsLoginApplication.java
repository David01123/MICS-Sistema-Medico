package com.mics.login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicsLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicsLoginApplication.class, args);
	}

}
